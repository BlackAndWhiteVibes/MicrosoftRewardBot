YOU NEED TO HAVE INSTALLED :
-Python
	[Next ~ are automatically installed if you don't do it yourself]
	~pip install selenium
	~pip install msedge-selenium-tools
-DefSettings.py
-Comptes.txt
				According to your choice :
-MicrosoftRewardBotChrome.py		|	-MicrosoftRewardBotEdge.py
-Chrome (updated)				|	-Edge (updated)
-chromedriver.exe (updated)		|	-msedgedriver.exe (updated)

		(Note : You can gain +12 points daily on edge)
		(You are more likely to have problems with edge) 



YOU NEED TO CONFIGURE BEFORE RUNNING :
-You need to use confighelper.hmtl to configure the file Comptes.txt


!!	At the beginning the gain of points will be reduced...!!
!!	...until the passage of the account to lv2 		!!
!!		(500 points on an account for lv2)			!!



IF YOU WANT TO START THIS PROGRAM EACH TIME YOU START YOUR COMPUTER :
	(It detect the day, so it can only start one time per day)
-Windows + R
-paste: shell:startup
-paste a SHORTCUT of the .py you use